package main

import (
	"bufio"
	"flag"
	"fmt"
	"io"
	_ "io/ioutil"
	"net/http"
	"os"
	"strings"
	"sync"
	"time"
)

var mu sync.Mutex
var payloadNum int
var wg sync.WaitGroup

var done chan bool = make(chan bool)

func scan(payload string, target string) {

	baseurl := "http://" + target + payload
	url := strings.Replace(baseurl, "\n", "", -1)
	//fmt.Println(url)
	resp, err := http.Get(url)
	if err == nil {
		if resp.StatusCode == 200 {
			fmt.Printf("\x1b[0;%dm 200       %s \n\x1b[0m", 35, url)

			return
		}
	}

	//判断https
	baseurl = "https://" + target + payload
	url = strings.Replace(baseurl, "\n", "", -1)
	resp, err = http.Get(url)
	if err == nil {
		if resp.StatusCode == 200 {
			fmt.Printf("\x1b[0;%dm 200       %s \n\x1b[0m", 35, url)
		}
	}

}

func main() {
	payloadFile := "/Users/jack/Documents/goProject/GScan/payload.txt"
	//var target string
	//var ThreadNum *int
	t := time.Now()

	payloadNum = 0
	target := flag.String("target", "127.0.0.1", "target IP")
	threadNum := flag.Int("thread", 10, "thread num")
	flag.Parse()

	fp, err := os.Open(payloadFile)
	if err != nil {
		panic(err)
	}
	defer fp.Close()

	buf := bufio.NewReader(fp)

	for i := 0; i < *threadNum; i++ {
		wg.Add(1)
		go createTask(buf, *target)
	}

	wg.Wait()
	elapsed := time.Since(t)
	fmt.Println(elapsed)
}

func createTask(buf *bufio.Reader, target string) {

	for {
		mu.Lock()
		line, err := buf.ReadString('\n')
		mu.Unlock()

		scan(line, target)

		if err != nil || err == io.EOF {
			return
			wg.Done()
		}
	}
}
